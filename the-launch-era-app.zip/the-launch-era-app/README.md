# THE LAUNCH ERA — App

Experiencia web interactiva que lleva a una persona de **"tengo una idea pero no sé cómo empezar"** a **"estoy creando y lanzando mi producto digital"**.

No es un ebook: es una app. Quiz de diagnóstico, journey por 6 eras, módulos interactivos con ejercicios editables, sistema de logros y una ceremonia final — todo con el sistema visual de **The Launch Era** (ink + lima, Anton + Space Grotesk).

**Marca:** [@dailinwithai](https://instagram.com/dailinwithai)

---

## ✦ Qué incluye

- **Welcome Screen** — hero de bienvenida y punto de entrada.
- **Quiz inicial** — 4 preguntas que diagnostican tu perfil (*Idea Explorer · Product Builder · Launch Ready*) y te llevan a tu era de partida.
- **Journey Dashboard** — barra de progreso dinámica + las 6 eras.
- **Módulos interactivos** — objetivo, mini-lección, ejercicio editable (autoguardado), checklist y botón de completar.
- **Sistema de logros** — 5 badges: Idea Creator, Product Builder, Brand Architect, Launch Ready, Digital Founder.
- **Final Celebration** — pantalla de cierre con confeti y siguiente paso.
- **Progreso persistente** con `localStorage` — sin registro, sin backend.

## ✦ Las 6 eras

| # | Era | Foco |
|---|-----|------|
| 01 | The Idea Era | Afilar la idea en una frase |
| 02 | The Product Era | Empaquetar el producto y su promesa |
| 03 | The Brand Era | Sistema de marca reconocible |
| 04 | The Creation Era | Producir los assets de lanzamiento |
| 05 | The Launch Era | Plan de lanzamiento con fecha y CTA |
| 06 | The Growth Era | Métrica-norte e iteración |

---

## ✦ Stack

- **React 18** + **Vite 5**
- **react-router-dom 6**
- **CSS moderno** con design tokens (custom properties), mobile-first
- **localStorage** para persistencia (sin dependencias de estado externas)

## ✦ Empezar

```bash
# 1. Instalar dependencias
npm install

# 2. Modo desarrollo
npm run dev

# 3. Build de producción
npm run build

# 4. Previsualizar el build
npm run preview
```

Abre el puerto que indique Vite (por defecto `http://localhost:5173`).

## ✦ Desplegar en Vercel

1. Sube este repo a GitHub.
2. En [vercel.com](https://vercel.com) → **New Project** → importa el repo.
3. Vercel detecta Vite automáticamente:
   - Build command: `npm run build`
   - Output directory: `dist`
4. Deploy. El `vercel.json` incluido gestiona las rutas del SPA (sin 404 al refrescar).

---

## ✦ Estructura

```
the-launch-era-app/
├── index.html
├── package.json
├── vite.config.js
├── vercel.json
├── public/
│   └── favicon.svg
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── components/
    │   ├── WelcomeScreen.jsx
    │   ├── Quiz.jsx
    │   ├── ModuleCard.jsx        # tarjeta interactiva completa
    │   ├── ModuleTile.jsx        # tile compacto para grillas
    │   ├── ProgressBar.jsx
    │   ├── BadgeSystem.jsx
    │   ├── FinalCelebration.jsx
    │   ├── Nav.jsx
    │   └── Signature.jsx
    ├── pages/
    │   ├── Home.jsx
    │   ├── Journey.jsx
    │   ├── Modules.jsx
    │   ├── Profile.jsx
    │   └── Celebration.jsx
    ├── context/
    │   └── ProgressContext.jsx   # estado + localStorage
    ├── data/
    │   ├── modules.js            # contenido de las 6 eras
    │   ├── quiz.js               # preguntas y lógica de resultado
    │   └── badges.js             # definición de logros
    └── styles/
        ├── tokens.css            # design tokens (fuente de verdad)
        └── global.css            # primitivos y animaciones
```

## ✦ Personalizar

- **Contenido de módulos:** edita `src/data/modules.js`. No toques los componentes — el journey es data-driven a propósito, para poder crecer sin refactor.
- **Colores / tipografía:** todo vive en `src/styles/tokens.css`.
- **Preguntas del quiz:** `src/data/quiz.js`.
- **Siguiente paso / oferta:** el botón final `GUÍA` en `FinalCelebration.jsx` es el punto donde conectas tu captura de leads o tu oferta.

---

## ✦ Sistema de diseño

| Token | Valor | Rol |
|-------|-------|-----|
| Ink | `#141018` | Fondo dominante |
| Ink 2 | `#1C1622` | Superficie / tarjeta |
| Lima | `#C6FF3D` | Único acento |
| Blanco frío | `#F4F5FF` | Texto |
| Violeta | `#6B21FF` | Guiño IA (moderado) |
| Display | Anton | Titulares all-caps |
| Texto | Space Grotesk | Cuerpo y datos |

Regla de oro: **un acento, una idea por pantalla, un CTA, firma siempre.**

---

## ✦ Licencia

MIT — úsalo, adáptalo, lánzalo.

import { Link } from 'react-router-dom'
import { useProgress } from '../context/ProgressContext'
import { modules } from '../data/modules'
import { results } from '../data/quiz'
import Quiz from '../components/Quiz'
import ProgressBar from '../components/ProgressBar'
import ModuleTile from '../components/ModuleTile'
import Signature from '../components/Signature'
import './Journey.css'

export default function Journey() {
  const { quizResult, progress, completedCount, total, allDone } =
    useProgress()

  // Sin diagnóstico → mostramos el quiz primero
  if (!quizResult) {
    return (
      <div className="wrap">
        <header className="page-head">
          <span className="eyebrow">Paso 1 · Diagnóstico</span>
          <h1 className="anton page-title">¿En qué era estás?</h1>
          <p className="lede">
            4 preguntas rápidas para saber por dónde empezar. Sin respuestas
            incorrectas.
          </p>
        </header>
        <Quiz />
        <Signature />
      </div>
    )
  }

  const profile = results[quizResult]

  return (
    <div className="wrap">
      <header className="page-head">
        <span className="eyebrow">Tu Launch Journey</span>
        <h1 className="anton page-title">
          Eres <span className="hl">{profile.title}</span>
        </h1>
        <p className="lede">{profile.summary}</p>
      </header>

      <div className="card journey__progress">
        <ProgressBar value={progress} label="Journey completado" />
        <div className="journey__stat">
          <span className="anton journey__statNum">
            {completedCount}
            <span className="journey__statOf">/{total}</span>
          </span>
          <span className="cap">eras completadas</span>
        </div>
      </div>

      {allDone && (
        <Link to="/celebration" className="journey__done">
          <div>
            <span className="cap">Journey completo</span>
            <div className="anton journey__doneTitle">
              Entra a tu Launch Era
            </div>
          </div>
          <span aria-hidden="true">→</span>
        </Link>
      )}

      <div className="journey__list">
        <span className="cap journey__listLabel">Las 6 eras</span>
        {modules.map((m) => (
          <ModuleTile key={m.id} module={m} />
        ))}
      </div>

      <Signature />
    </div>
  )
}

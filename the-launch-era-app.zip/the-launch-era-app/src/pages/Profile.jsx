import { Link } from 'react-router-dom'
import { useProgress } from '../context/ProgressContext'
import { results } from '../data/quiz'
import ProgressBar from '../components/ProgressBar'
import BadgeSystem from '../components/BadgeSystem'
import Signature from '../components/Signature'
import './Profile.css'

export default function Profile() {
  const { quizResult, progress, earnedBadges, allDone, resetAll } =
    useProgress()
  const profile = quizResult ? results[quizResult] : null

  function handleReset() {
    const ok = window.confirm(
      'Esto borra tu progreso, ejercicios y logros guardados en este dispositivo. ¿Seguro?'
    )
    if (ok) resetAll()
  }

  return (
    <div className="wrap">
      <header className="page-head">
        <span className="eyebrow">Tu perfil</span>
        <h1 className="anton page-title">
          {profile ? (
            <>
              <span className="hl">{profile.title}</span>
            </>
          ) : (
            'Aún sin diagnóstico'
          )}
        </h1>
        <p className="lede">
          {profile
            ? profile.summary
            : 'Haz el diagnóstico para descubrir en qué era estás.'}
        </p>
      </header>

      {!profile && (
        <Link to="/journey" className="btn btn--cta btn--block profile__start">
          Hacer el diagnóstico <span aria-hidden="true">→</span>
        </Link>
      )}

      <div className="card profile__progress">
        <ProgressBar value={progress} label="Progreso total" />
      </div>

      {allDone && (
        <Link to="/celebration" className="profile__doneLink">
          <span className="pill pill--lima">Journey completo</span>
          <span>Ver tu ceremonia de lanzamiento →</span>
        </Link>
      )}

      <section className="profile__section">
        <div className="profile__sectionHead">
          <span className="cap">Logros</span>
          <span className="profile__count">
            {earnedBadges.length}/5 desbloqueados
          </span>
        </div>
        <BadgeSystem />
      </section>

      <button className="profile__reset" onClick={handleReset}>
        Reiniciar mi journey
      </button>

      <Signature />
    </div>
  )
}

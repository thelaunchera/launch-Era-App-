import { useParams, Navigate } from 'react-router-dom'
import { modules, getModule } from '../data/modules'
import ModuleCard from '../components/ModuleCard'
import ModuleTile from '../components/ModuleTile'
import Signature from '../components/Signature'
import './Modules.css'

export default function Modules() {
  const { id } = useParams()

  // Detalle interactivo de un módulo
  if (id) {
    const module = getModule(id)
    if (!module) return <Navigate to="/modules" replace />
    return (
      <div className="wrap">
        <ModuleCard module={module} />
      </div>
    )
  }

  // Grilla de todos los módulos
  return (
    <div className="wrap">
      <header className="page-head">
        <span className="eyebrow">Los módulos</span>
        <h1 className="anton page-title">6 eras, un producto</h1>
        <p className="lede">
          Cada era es una decisión que te acerca al lanzamiento. Ábrelas en
          orden o salta a la tuya.
        </p>
      </header>

      <div className="modules__grid">
        {modules.map((m) => (
          <ModuleTile key={m.id} module={m} />
        ))}
      </div>

      <Signature />
    </div>
  )
}

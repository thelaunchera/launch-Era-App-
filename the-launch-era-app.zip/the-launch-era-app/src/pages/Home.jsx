import WelcomeScreen from '../components/WelcomeScreen'
import Signature from '../components/Signature'

export default function Home() {
  return (
    <div className="wrap">
      <WelcomeScreen />
      <Signature />
    </div>
  )
}

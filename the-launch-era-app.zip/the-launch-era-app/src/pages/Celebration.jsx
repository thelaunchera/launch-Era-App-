import { Navigate } from 'react-router-dom'
import { useProgress } from '../context/ProgressContext'
import FinalCelebration from '../components/FinalCelebration'

export default function Celebration() {
  const { allDone } = useProgress()
  // La ceremonia solo tiene sentido con el journey completo
  if (!allDone) return <Navigate to="/journey" replace />
  return (
    <div className="wrap">
      <FinalCelebration />
    </div>
  )
}

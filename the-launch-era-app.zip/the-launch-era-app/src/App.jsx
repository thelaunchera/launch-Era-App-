import { useEffect } from 'react'
import {
  BrowserRouter,
  Routes,
  Route,
  useLocation,
} from 'react-router-dom'
import { ProgressProvider } from './context/ProgressContext'
import Nav from './components/Nav'
import Home from './pages/Home'
import Journey from './pages/Journey'
import Modules from './pages/Modules'
import Profile from './pages/Profile'
import Celebration from './pages/Celebration'

function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pathname])
  return null
}

export default function App() {
  return (
    <ProgressProvider>
      <BrowserRouter>
        <ScrollToTop />
        <main className="app-shell">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/journey" element={<Journey />} />
            <Route path="/modules" element={<Modules />} />
            <Route path="/modules/:id" element={<Modules />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/celebration" element={<Celebration />} />
            <Route path="*" element={<Home />} />
          </Routes>
        </main>
        <Nav />
      </BrowserRouter>
    </ProgressProvider>
  )
}

import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { questions, scoreQuiz } from '../data/quiz'
import { useProgress } from '../context/ProgressContext'
import './Quiz.css'

export default function Quiz({ onDone }) {
  const navigate = useNavigate()
  const { setQuizResult } = useProgress()
  const [step, setStep] = useState(0)
  const [answers, setAnswers] = useState([])
  const [result, setResult] = useState(null)

  const q = questions[step]
  const isLast = step === questions.length - 1

  function choose(profile) {
    const next = [...answers, profile]
    setAnswers(next)
    if (isLast) {
      const res = scoreQuiz(next)
      setResult(res)
      setQuizResult(res.key)
    } else {
      setStep((s) => s + 1)
    }
  }

  if (result) {
    return (
      <div className="quiz quiz--result" role="status">
        <span className="pill pill--ghost">{result.tag}</span>
        <div className="quiz__resultTitle anton">
          Eres <span className="hl">{result.title}</span>
        </div>
        <p className="quiz__resultSummary">{result.summary}</p>

        <div className="card quiz__next">
          <span className="cap">Tu punto de partida</span>
          <p className="quiz__nextTip">
            Te recomiendo empezar por tu era actual. Ahí es donde vas a
            avanzar más rápido.
          </p>
          <button
            className="btn btn--cta btn--block"
            onClick={() => navigate(`/modules/${result.startModule}`)}
          >
            Empezar por mi era <span aria-hidden="true">→</span>
          </button>
          <button
            className="quiz__skip"
            onClick={() => (onDone ? onDone() : navigate('/journey'))}
          >
            Ver el journey completo
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="quiz">
      <div className="quiz__progress">
        <span className="cap">
          Diagnóstico · {step + 1}/{questions.length}
        </span>
        <div className="quiz__dots">
          {questions.map((_, i) => (
            <span
              key={i}
              className={'quiz__dot' + (i <= step ? ' is-on' : '')}
            />
          ))}
        </div>
      </div>

      <h2 className="quiz__prompt anton" key={q.id}>
        {q.prompt}
      </h2>

      <div className="quiz__options stack">
        {q.options.map((opt) => (
          <button
            key={opt.label}
            className="quiz__option"
            onClick={() => choose(opt.profile)}
          >
            <span>{opt.label}</span>
            <span className="quiz__arrow" aria-hidden="true">
              →
            </span>
          </button>
        ))}
      </div>
    </div>
  )
}

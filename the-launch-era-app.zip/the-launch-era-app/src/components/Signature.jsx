export default function Signature() {
  return <div className="signature">@dailinwithai</div>
}

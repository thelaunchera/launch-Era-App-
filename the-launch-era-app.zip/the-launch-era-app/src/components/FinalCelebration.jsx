import { useEffect, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useProgress } from '../context/ProgressContext'
import './FinalCelebration.css'

export default function FinalCelebration() {
  const navigate = useNavigate()
  const { earnedBadges, markCelebrated } = useProgress()

  useEffect(() => {
    markCelebrated()
  }, [markCelebrated])

  // Confeti determinista (lima/violeta/blanco), respeta reduce-motion vía CSS
  const confetti = useMemo(
    () =>
      Array.from({ length: 28 }, (_, i) => ({
        left: (i * 37) % 100,
        delay: (i % 10) * 0.22,
        dur: 2.6 + ((i * 13) % 18) / 10,
        color: ['var(--lima)', 'var(--violet)', 'var(--white-cold)'][i % 3],
        size: 6 + (i % 4) * 2,
      })),
    []
  )

  return (
    <section className="final">
      <div className="final__confetti" aria-hidden="true">
        {confetti.map((c, i) => (
          <span
            key={i}
            style={{
              left: `${c.left}%`,
              animationDelay: `${c.delay}s`,
              animationDuration: `${c.dur}s`,
              background: c.color,
              width: `${c.size}px`,
              height: `${c.size}px`,
            }}
          />
        ))}
      </div>

      <span className="pill pill--lima final__tab">Ceremonia</span>

      <p className="eyebrow final__eyebrow">Journey completo</p>
      <h1 className="anton final__title">
        Entras oficialmente a tu <span className="hl">Launch Era</span>.
      </h1>
      <p className="final__msg">
        Pasaste de una idea suelta a un producto con marca, plan y fecha.
        Eso no es suerte: es un sistema. Y ahora es tuyo.
      </p>

      <div className="final__badges">
        <span className="cap">Logros conseguidos</span>
        <div className="final__badgeRow">
          {earnedBadges.map((b) => (
            <span key={b.id} className="final__badgeChip">
              ✦ {b.name}
            </span>
          ))}
        </div>
      </div>

      {/* Siguiente paso real: aquí conectas tu oferta / captura de leads */}
      <div className="card final__cta">
        <span className="cap">Tu siguiente paso</span>
        <p className="final__ctaTip">
          Comparte tu lanzamiento y sigue el sistema. Cuando quieras la guía
          completa, ya sabes la palabra.
        </p>
        <button className="btn btn--cta btn--block">
          GUÍA <span aria-hidden="true">→</span>
        </button>
        <button
          className="btn btn--ghost btn--block final__replay"
          onClick={() => navigate('/journey')}
        >
          Volver a mi journey
        </button>
      </div>

      <div className="signature">@dailinwithai</div>
    </section>
  )
}

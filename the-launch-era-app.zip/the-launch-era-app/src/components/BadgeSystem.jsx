import { badges as allBadges } from '../data/badges'
import { useProgress } from '../context/ProgressContext'
import './BadgeSystem.css'

export default function BadgeSystem() {
  const { earnedBadges } = useProgress()
  const earnedIds = new Set(earnedBadges.map((b) => b.id))

  return (
    <div className="badges">
      {allBadges.map((b) => {
        const unlocked = earnedIds.has(b.id)
        return (
          <div
            key={b.id}
            className={'badge' + (unlocked ? ' is-unlocked' : ' is-locked')}
          >
            <span className="badge__mark" aria-hidden="true">
              {unlocked ? '✦' : '✧'}
            </span>
            <div className="badge__body">
              <div className="badge__name anton">{b.name}</div>
              <p className="badge__caption">
                {unlocked ? b.caption : 'Aún por desbloquear'}
              </p>
            </div>
          </div>
        )
      })}
    </div>
  )
}

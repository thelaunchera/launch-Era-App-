import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useProgress } from '../context/ProgressContext'
import { modules, moduleIndex } from '../data/modules'
import { getBadge } from '../data/badges'
import './ModuleCard.css'

export default function ModuleCard({ module }) {
  const navigate = useNavigate()
  const {
    exercises,
    checklists,
    saveExercise,
    toggleCheck,
    completeModule,
    isCompleted,
  } = useProgress()

  const done = isCompleted(module.id)
  const [justDone, setJustDone] = useState(false)

  const exerciseValue = exercises[module.id] || ''
  const checkState =
    checklists[module.id] || Array(module.checklist.length).fill(false)
  const allChecked = checkState.every(Boolean)

  const idx = moduleIndex(module.id)
  const next = modules[idx + 1]

  function handleComplete() {
    completeModule(module.id)
    setJustDone(true)
  }

  const unlockedBadge = module.badge ? getBadge(module.badge) : null

  return (
    <article className="mcard">
      <button
        className="mcard__back"
        onClick={() => navigate('/modules')}
        aria-label="Volver a módulos"
      >
        ← Módulos
      </button>

      <div className="mcard__head">
        <div className="mcard__headTop">
          <span className="mcard__code anton">{module.code}</span>
          <span className="pill pill--ghost">{module.tag}</span>
        </div>
        <h1 className="mcard__title anton">{module.title}</h1>
      </div>

      {/* Objetivo */}
      <div className="mcard__objective">
        <span className="module__label">El objetivo</span>
        <p>{module.objective}</p>
      </div>

      {/* Mini lección */}
      <section className="mcard__section">
        <span className="cap mcard__kicker">Mini lección</span>
        <div className="mcard__lesson stack">
          {module.lesson.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>
      </section>

      {/* Ejercicio editable */}
      <section className="mcard__section">
        <span className="cap mcard__kicker">Tu turno</span>
        <label className="mcard__exLabel" htmlFor={`ex-${module.id}`}>
          {module.exercise.label}
        </label>
        <textarea
          id={`ex-${module.id}`}
          rows={4}
          value={exerciseValue}
          placeholder={module.exercise.placeholder}
          onChange={(e) => saveExercise(module.id, e.target.value)}
        />
        <span className="mcard__saved">
          {exerciseValue ? '✓ Guardado automáticamente' : 'Se guarda solo'}
        </span>
      </section>

      {/* Checklist */}
      <section className="mcard__section">
        <span className="cap mcard__kicker">Checklist</span>
        <ul className="mcard__checklist">
          {module.checklist.map((item, i) => (
            <li key={i}>
              <button
                className={'check' + (checkState[i] ? ' is-on' : '')}
                onClick={() =>
                  toggleCheck(module.id, i, module.checklist.length)
                }
                aria-pressed={checkState[i]}
              >
                <span className="check__box" aria-hidden="true">
                  <svg viewBox="0 0 24 24">
                    <path d="M5 13l4 4L19 7" />
                  </svg>
                </span>
                <span className="check__label">{item}</span>
              </button>
            </li>
          ))}
        </ul>
      </section>

      {/* Completar */}
      <section className="mcard__complete">
        {!done && (
          <>
            <button
              className="btn btn--cta btn--block"
              onClick={handleComplete}
              disabled={!allChecked}
            >
              Completar módulo
            </button>
            {!allChecked && (
              <p className="mcard__gate muted">
                Marca todo el checklist para completar esta era.
              </p>
            )}
          </>
        )}

        {done && (
          <div className="mcard__doneState">
            {justDone && unlockedBadge && (
              <div className="mcard__badgePop">
                <span className="mcard__badgeStar" aria-hidden="true">
                  ✦
                </span>
                <div>
                  <span className="cap">Logro desbloqueado</span>
                  <div className="mcard__badgeName anton">
                    {unlockedBadge.name}
                  </div>
                </div>
              </div>
            )}
            <div className="mcard__doneRow">
              <span className="pill pill--lima">Era completada</span>
            </div>
            {next ? (
              <button
                className="btn btn--cta btn--block"
                onClick={() => navigate(`/modules/${next.id}`)}
              >
                Siguiente: {next.era} <span aria-hidden="true">→</span>
              </button>
            ) : (
              <button
                className="btn btn--cta btn--block"
                onClick={() => navigate('/celebration')}
              >
                Ver tu ceremonia de lanzamiento{' '}
                <span aria-hidden="true">→</span>
              </button>
            )}
            <button
              className="btn btn--ghost btn--block"
              onClick={() => navigate('/journey')}
            >
              Volver al journey
            </button>
          </div>
        )}
      </section>

      <div className="signature">@dailinwithai</div>
    </article>
  )
}

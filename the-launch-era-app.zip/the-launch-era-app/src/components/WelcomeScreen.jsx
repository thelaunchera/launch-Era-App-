import { useNavigate } from 'react-router-dom'
import { useProgress } from '../context/ProgressContext'
import './WelcomeScreen.css'

export default function WelcomeScreen() {
  const navigate = useNavigate()
  const { quizResult, completedCount } = useProgress()
  const hasStarted = quizResult || completedCount > 0

  return (
    <section className="welcome">
      <span className="pill pill--lima welcome__tab">The Launch Era</span>

      <div className="eyebrow">Bienvenida · v1</div>

      <h1 className="anton welcome__title">
        Bienvenida a tu<br />
        <span className="hl">Launch&nbsp;Era</span>
      </h1>

      <p className="welcome__msg">
        Tu idea merece convertirse en algo real. Aquí la llevamos de
        <b> "no sé por dónde empezar"</b> a <b>"estoy lanzando mi primer
        producto digital"</b>.
      </p>

      <div className="welcome__actions">
        <button
          className="btn btn--cta btn--block"
          onClick={() => navigate('/journey')}
        >
          {hasStarted ? 'Continuar mi journey' : 'Empezar mi journey'}
          <span aria-hidden="true">→</span>
        </button>
        {!hasStarted && (
          <p className="welcome__hint muted">
            2 minutos · sin registro · tu progreso se guarda solo
          </p>
        )}
      </div>

      <div className="welcome__meta">
        <span>
          <b>6</b> eras
        </span>
        <span>
          <b>5</b> logros
        </span>
        <span>
          <b>1</b> producto lanzado
        </span>
      </div>
    </section>
  )
}

import { NavLink } from 'react-router-dom'
import './Nav.css'

const items = [
  { to: '/', label: 'Inicio', end: true, icon: HomeIcon },
  { to: '/journey', label: 'Journey', icon: PathIcon },
  { to: '/modules', label: 'Módulos', icon: GridIcon },
  { to: '/profile', label: 'Perfil', icon: StarIcon },
]

export default function Nav() {
  return (
    <nav className="nav" aria-label="Navegación principal">
      <div className="nav__inner">
        {items.map(({ to, label, end, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            className={({ isActive }) =>
              'nav__link' + (isActive ? ' is-active' : '')
            }
          >
            <Icon />
            <span>{label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  )
}

/* --- Íconos de línea 1.6px, coherentes con el design system --- */
function HomeIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M4 11l8-7 8 7" />
      <path d="M6 10v9h12v-9" />
    </svg>
  )
}
function PathIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M6 3v6a3 3 0 0 0 3 3h6a3 3 0 0 1 3 3v6" />
      <circle cx="6" cy="3" r="1.6" />
      <circle cx="18" cy="21" r="1.6" />
    </svg>
  )
}
function GridIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <rect x="4" y="4" width="7" height="7" rx="1.5" />
      <rect x="13" y="4" width="7" height="7" rx="1.5" />
      <rect x="4" y="13" width="7" height="7" rx="1.5" />
      <rect x="13" y="13" width="7" height="7" rx="1.5" />
    </svg>
  )
}
function StarIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 3l2.4 5.2L20 9l-4 4 1 6-5-2.8L7 19l1-6-4-4 5.6-.8z" />
    </svg>
  )
}

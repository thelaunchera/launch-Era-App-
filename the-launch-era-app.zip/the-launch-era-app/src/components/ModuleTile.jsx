import { Link } from 'react-router-dom'
import { useProgress } from '../context/ProgressContext'
import './ModuleTile.css'

export default function ModuleTile({ module }) {
  const { isCompleted } = useProgress()
  const done = isCompleted(module.id)

  return (
    <Link
      to={`/modules/${module.id}`}
      className={'mtile' + (done ? ' is-done' : '')}
    >
      <div className="mtile__top">
        <span className="mtile__code anton">{module.code}</span>
        {done ? (
          <span className="mtile__check" aria-label="Completado">
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M5 13l4 4L19 7" />
            </svg>
          </span>
        ) : (
          <span className="pill pill--muted">{module.tag}</span>
        )}
      </div>
      <h3 className="mtile__title anton">{module.era}</h3>
      <p className="mtile__obj">{module.objective}</p>
      <span className="mtile__go">
        {done ? 'Revisar' : 'Abrir'} <span aria-hidden="true">→</span>
      </span>
    </Link>
  )
}

import './ProgressBar.css'

export default function ProgressBar({ value = 0, label = 'Tu progreso' }) {
  return (
    <div className="progressbar" role="group" aria-label={label}>
      <div className="progressbar__head">
        <span className="cap">{label}</span>
        <span className="progressbar__pct anton">{value}%</span>
      </div>
      <div
        className="progressbar__track"
        role="progressbar"
        aria-valuenow={value}
        aria-valuemin={0}
        aria-valuemax={100}
      >
        <div className="progressbar__fill" style={{ width: `${value}%` }} />
      </div>
    </div>
  )
}

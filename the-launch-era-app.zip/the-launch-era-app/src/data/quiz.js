/**
 * THE LAUNCH ERA — Quiz inicial
 * ------------------------------------------------------------
 * Diagnóstico de 4 preguntas. Cada respuesta suma puntos a un
 * perfil. El resultado NO es cosmético: define el módulo por el
 * que la persona debería empezar (startModule).
 */

export const questions = [
  {
    id: 'q1',
    prompt: '¿En qué punto estás hoy con tu idea?',
    options: [
      { label: 'Tengo mil ideas y ninguna clara', profile: 'explorer' },
      { label: 'Tengo una idea, pero no sé cómo hacerla producto', profile: 'builder' },
      { label: 'Ya tengo el producto casi listo, me falta lanzar', profile: 'launcher' },
    ],
  },
  {
    id: 'q2',
    prompt: '¿Qué te frena más ahora mismo?',
    options: [
      { label: 'No sé qué idea perseguir', profile: 'explorer' },
      { label: 'No sé cómo empaquetar lo que sé', profile: 'builder' },
      { label: 'Me da miedo (o pereza) darle al botón de lanzar', profile: 'launcher' },
    ],
  },
  {
    id: 'q3',
    prompt: '¿Tienes una marca reconocible?',
    options: [
      { label: 'Todavía no pienso en marca', profile: 'explorer' },
      { label: 'Estoy definiéndola', profile: 'builder' },
      { label: 'Ya tengo un sistema visual y una voz', profile: 'launcher' },
    ],
  },
  {
    id: 'q4',
    prompt: '¿Cuál sería una victoria real en 30 días?',
    options: [
      { label: 'Elegir por fin UNA idea', profile: 'explorer' },
      { label: 'Tener mi primer producto armado', profile: 'builder' },
      { label: 'Lanzar y conseguir mis primeras ventas', profile: 'launcher' },
    ],
  },
]

export const results = {
  explorer: {
    key: 'explorer',
    title: 'Idea Explorer',
    tag: 'Empieza aquí',
    summary:
      'Tienes energía y visión — te falta foco. Tu era ahora es afilar una sola idea hasta que sea imposible ignorarla.',
    startModule: 'idea',
    accent: 'lima',
  },
  builder: {
    key: 'builder',
    title: 'Product Builder',
    tag: 'En construcción',
    summary:
      'Ya sabes qué quieres crear. Ahora toca empaquetarlo: convertir lo que sabes en un producto con una promesa clara.',
    startModule: 'product',
    accent: 'lima',
  },
  launcher: {
    key: 'launcher',
    title: 'Launch Ready',
    tag: 'Casi en órbita',
    summary:
      'Tienes casi todo. Lo único entre tú y tu Launch Era es el plan de lanzamiento y darle al botón. Vamos por ahí.',
    startModule: 'launch',
    accent: 'lima',
  },
}

/** Cuenta perfiles y devuelve el ganador (con desempate por orden de avance). */
export function scoreQuiz(answers) {
  const tally = { explorer: 0, builder: 0, launcher: 0 }
  answers.forEach((profile) => {
    if (tally[profile] !== undefined) tally[profile] += 1
  })
  const order = ['launcher', 'builder', 'explorer'] // desempate: más avanzado gana
  let winner = 'explorer'
  let max = -1
  order.forEach((p) => {
    if (tally[p] > max) {
      max = tally[p]
      winner = p
    }
  })
  return results[winner]
}

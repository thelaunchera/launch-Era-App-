/**
 * THE LAUNCH ERA — Sistema de logros
 * Cada badge se desbloquea al completar su módulo asociado
 * (ver campo `badge` en modules.js). "digital-founder" corona
 * el journey completo.
 */
export const badges = [
  {
    id: 'idea-creator',
    name: 'Idea Creator',
    caption: 'Afilaste tu idea hasta una sola frase.',
  },
  {
    id: 'product-builder',
    name: 'Product Builder',
    caption: 'Empaquetaste tu conocimiento en un producto.',
  },
  {
    id: 'brand-architect',
    name: 'Brand Architect',
    caption: 'Diseñaste un sistema de marca reconocible.',
  },
  {
    id: 'launch-ready',
    name: 'Launch Ready',
    caption: 'Tienes un plan de lanzamiento con fecha.',
  },
  {
    id: 'digital-founder',
    name: 'Digital Founder',
    caption: 'Completaste el journey. Bienvenida a tu Launch Era.',
  },
]

export const getBadge = (id) => badges.find((b) => b.id === id)

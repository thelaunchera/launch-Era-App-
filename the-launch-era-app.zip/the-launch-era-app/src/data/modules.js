/**
 * THE LAUNCH ERA — Contenido de módulos
 * ------------------------------------------------------------
 * Todo el journey vive aquí. Para añadir o editar un módulo,
 * NO toques los componentes: edita este archivo. Ese es el
 * principio que vuelve la app un producto escalable, no un one-off.
 *
 * Cada módulo:
 *  id         → orden y clave estable
 *  code       → "01".."06"
 *  era        → nombre corto de la etapa
 *  title      → título completo
 *  tag        → categoría (pill superior)
 *  objective  → una frase: qué logras al terminar
 *  lesson     → 2–3 párrafos de mini-lección
 *  exercise   → { label, placeholder } editable (se guarda en localStorage)
 *  checklist  → items accionables (estado guardado en localStorage)
 *  badge      → id del badge que desbloquea al completar (o null)
 */

export const modules = [
  {
    id: 'idea',
    code: '01',
    era: 'The Idea Era',
    title: 'The Idea Era',
    tag: 'Aprende',
    objective: 'Convertir "tengo una idea" en una frase clara que otra persona entienda en 10 segundos.',
    lesson: [
      'La mayoría no se traba por falta de ideas, sino por falta de foco. Una idea vaga no se puede construir ni vender. El primer trabajo no es tener más ideas: es afilar una.',
      'La fórmula es simple y brutal: ayudo a [para quién] a [conseguir qué] sin [el dolor de siempre]. Si no puedes completarla, todavía no tienes un producto — tienes un tema.',
      'No busques la idea perfecta. Busca la idea clara. La claridad es lo que hace que alguien diga "esto es para mí" antes de que le expliques nada.',
    ],
    exercise: {
      label: 'Tu idea en una frase',
      placeholder:
        'Ayudo a ___________ a ___________ sin ___________.',
    },
    checklist: [
      'Puedo nombrar a UNA persona concreta que tiene este problema',
      'Puedo describir el problema con sus palabras, no las mías',
      'Mi idea cabe en una sola frase sin "y también"',
    ],
    badge: 'idea-creator',
  },
  {
    id: 'product',
    code: '02',
    era: 'The Product Era',
    title: 'The Product Era',
    tag: 'Guía',
    objective: 'Definir el formato de tu primer producto digital y la promesa concreta que entrega.',
    lesson: [
      'Un producto digital no es "todo lo que sabes". Es una transformación empaquetada: alguien entra en un punto A y sale en un punto B. Tu trabajo es elegir un solo A→B y hacerlo bien.',
      'Empieza pequeño a propósito. Una guía, un mini-curso, una plantilla, un checklist premium. El primer producto no demuestra todo tu conocimiento: demuestra que puedes entregar un resultado. La escala viene después.',
      'La promesa manda sobre el formato. Define primero qué resultado prometes ("sales con tu primer carrusel publicado") y el formato se elige solo.',
    ],
    exercise: {
      label: 'Tu producto en formato + promesa',
      placeholder:
        'Formato: (guía / plantilla / mini-curso...)\nPromesa: al terminar, la persona podrá ___________.',
    },
    checklist: [
      'Elegí UN solo formato para el primer producto',
      'La promesa es un resultado, no un tema',
      'Se puede consumir en menos de una semana',
    ],
    badge: 'product-builder',
  },
  {
    id: 'brand',
    code: '03',
    era: 'The Brand Era',
    title: 'The Brand Era',
    tag: 'IA',
    objective: 'Fijar los pocos elementos que hacen tu marca reconocible: nombre, tono, un acento y una tipografía.',
    lesson: [
      'La marca no es un logo bonito: es repetición inteligente. Lo que hace que un feed se vea "con sistema" es un esqueleto fijo, un solo acento que dirige el ojo y una voz constante. Cambia el contenido, no la estructura.',
      'Menos decisiones, más disciplina. Un color acento (no cinco), dos tipografías (una que grita, una que trabaja), una palabra-CTA que repites siempre. La restricción es lo premium: el vacío y un solo acento pesan más que el ruido.',
      'Tu marca debe ser reconocible sin tu nombre encima. Si alguien tapara tu @ y aun así supiera que es tuyo, ganaste.',
    ],
    exercise: {
      label: 'Tu sistema mínimo de marca',
      placeholder:
        'Nombre / handle:\nTono en 3 palabras:\nColor acento:\nPalabra-CTA que repetirás:',
    },
    checklist: [
      'Tengo UN color acento definido (no una paleta entera)',
      'Elegí máximo 2 tipografías con roles claros',
      'Tengo una palabra-CTA que repetiré siempre',
      'Mi marca se reconoce sin mi nombre encima',
    ],
    badge: 'brand-architect',
  },
  {
    id: 'creation',
    code: '04',
    era: 'The Creation Era',
    title: 'The Creation Era',
    tag: 'Aprende',
    objective: 'Producir los assets clave del lanzamiento con un esqueleto fijo que puedas repetir.',
    lesson: [
      'Crear no es empezar de cero cada vez. Es tener plantillas: un esqueleto para la portada, uno para el carrusel de valor, uno para el cierre con CTA. Rellenas el contenido, no rediseñas la casa.',
      'Una idea por lámina. Líneas cortas. Un solo acento por pieza. La IA acelera el borrador, pero la disciplina del sistema es lo que hace que todo se vea de la misma marca.',
      'No necesitas 40 piezas para lanzar. Necesitas las correctas: el gancho, la prueba, la oferta y el CTA. Menos piezas, mejor ejecutadas.',
    ],
    exercise: {
      label: 'Tus 3 assets mínimos de lanzamiento',
      placeholder:
        '1. Portada / gancho:\n2. Pieza de valor (dato o prompt):\n3. Cierre con CTA:',
    },
    checklist: [
      'Tengo un esqueleto fijo para portada, valor y cierre',
      'Cada pieza defiende UNA sola idea',
      'Uso un solo acento por pieza',
      'Mi firma / @ aparece en cada pieza',
    ],
    badge: null,
  },
  {
    id: 'launch',
    code: '05',
    era: 'The Launch Era',
    title: 'The Launch Era',
    tag: 'Ventas',
    objective: 'Armar un plan de lanzamiento real: fecha, oferta y una sola llamada a la acción.',
    lesson: [
      'Lanzar no es publicar y esperar. Es una secuencia: calientas, muestras la prueba, abres la oferta y repites el mismo CTA hasta que canse (a ti, no a la audiencia). La consistencia vende más que la novedad.',
      'Una oferta, un objetivo, un CTA. Si tu lanzamiento tiene tres llamadas a la acción distintas, no tiene ninguna. Elige la palabra-CTA de tu marca y repítela sin miedo.',
      'La fecha crea el producto. Sin fecha, el lanzamiento es un "algún día". Ponle día, aunque sea pequeño. Lo lanzado imperfecto le gana a lo perfecto sin publicar.',
    ],
    exercise: {
      label: 'Tu plan de lanzamiento',
      placeholder:
        'Fecha de lanzamiento:\nOferta concreta:\nCTA único (una palabra):\nDónde lo anuncio primero:',
    },
    checklist: [
      'Tengo una fecha concreta puesta',
      'Mi lanzamiento tiene UN solo CTA',
      'Definí la oferta con claridad',
      'Sé dónde lo anuncio primero',
    ],
    badge: 'launch-ready',
  },
  {
    id: 'growth',
    code: '06',
    era: 'The Growth Era',
    title: 'The Growth Era',
    tag: 'Guía',
    objective: 'Elegir la métrica que importa e iterar sobre lo que ya funciona en lugar de reinventar.',
    lesson: [
      'Crecer no es hacer más cosas: es repetir lo que funcionó. Después de lanzar, tu trabajo es leer los datos sin drama — qué se guardó, qué convirtió, qué aburrió — y doblar la apuesta en lo que ya jaló.',
      'Elige una sola métrica-norte por temporada (guardados, leads, ventas). Perseguir cinco métricas a la vez es no perseguir ninguna.',
      'El sistema es el activo. Cada pieza que funciona vuelve plantilla; cada plantilla te hace más rápida la próxima vez. Así una idea se convierte en un negocio, no en un evento.',
    ],
    exercise: {
      label: 'Tu norte de crecimiento',
      placeholder:
        'Métrica-norte de esta temporada:\nQué funcionó que voy a repetir:\nSiguiente experimento pequeño:',
    },
    checklist: [
      'Elegí UNA métrica-norte',
      'Identifiqué qué repetir de lo que ya funcionó',
      'Tengo un próximo experimento pequeño definido',
    ],
    badge: 'digital-founder',
  },
]

export const getModule = (id) => modules.find((m) => m.id === id)
export const moduleIndex = (id) => modules.findIndex((m) => m.id === id)

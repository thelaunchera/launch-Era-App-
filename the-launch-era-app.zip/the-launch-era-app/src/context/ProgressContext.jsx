import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { modules } from '../data/modules'
import { badges as allBadges } from '../data/badges'

const STORAGE_KEY = 'launch-era:v1'

const emptyState = {
  quizResult: null,       // key del resultado del quiz: 'explorer' | 'builder' | 'launcher'
  completed: [],          // ids de módulos completados
  exercises: {},          // { [moduleId]: string }
  checklists: {},         // { [moduleId]: [bool, bool, ...] }
  celebrated: false,      // ya vio la pantalla final
}

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return emptyState
    return { ...emptyState, ...JSON.parse(raw) }
  } catch {
    return emptyState
  }
}

const ProgressContext = createContext(null)

export function ProgressProvider({ children }) {
  const [state, setState] = useState(load)

  // Persistir en cada cambio
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
    } catch {
      /* almacenamiento no disponible (modo incógnito, etc.) */
    }
  }, [state])

  // ---- Derivados ----
  const total = modules.length
  const completedCount = state.completed.length
  const progress = total ? Math.round((completedCount / total) * 100) : 0

  const earnedBadges = useMemo(() => {
    const ids = new Set()
    modules.forEach((m) => {
      if (m.badge && state.completed.includes(m.id)) ids.add(m.badge)
    })
    if (completedCount === total && total > 0) ids.add('digital-founder')
    return allBadges.filter((b) => ids.has(b.id))
  }, [state.completed, completedCount, total])

  const allDone = completedCount === total && total > 0

  // ---- Acciones ----
  const setQuizResult = (key) =>
    setState((s) => ({ ...s, quizResult: key }))

  const isCompleted = (id) => state.completed.includes(id)

  const completeModule = (id) =>
    setState((s) =>
      s.completed.includes(id)
        ? s
        : { ...s, completed: [...s.completed, id] }
    )

  const uncompleteModule = (id) =>
    setState((s) => ({
      ...s,
      completed: s.completed.filter((x) => x !== id),
    }))

  const saveExercise = (id, value) =>
    setState((s) => ({ ...s, exercises: { ...s.exercises, [id]: value } }))

  const toggleCheck = (id, index, length) =>
    setState((s) => {
      const current = s.checklists[id] || Array(length).fill(false)
      const next = current.slice()
      next[index] = !next[index]
      return { ...s, checklists: { ...s.checklists, [id]: next } }
    })

  const markCelebrated = () =>
    setState((s) => ({ ...s, celebrated: true }))

  const resetAll = () => setState(emptyState)

  const value = {
    ...state,
    total,
    completedCount,
    progress,
    earnedBadges,
    allDone,
    setQuizResult,
    isCompleted,
    completeModule,
    uncompleteModule,
    saveExercise,
    toggleCheck,
    markCelebrated,
    resetAll,
  }

  return (
    <ProgressContext.Provider value={value}>
      {children}
    </ProgressContext.Provider>
  )
}

export function useProgress() {
  const ctx = useContext(ProgressContext)
  if (!ctx) throw new Error('useProgress debe usarse dentro de <ProgressProvider>')
  return ctx
}
